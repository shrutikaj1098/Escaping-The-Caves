Steps to Run Assignment :

1.generate_plain.py : generates plaintexts required for breaking encryption and stores in plain_texts.txt

2.run_script.pynb : Establishes connection to game server and generates ciphertext corresponding to plaintext in plain_texts.txt and stores in cipher_text.txt and then processes it to get in desired format and stores this as cipher_texts.txt

3.decrpytCipher.py : Uses plaintext-ciphertext pairs to figure out Linear Transformation Matrix A and Exponent Vector E and then performs reverse operation on given ciphertext from game to decrypt it to get level password.

Note : You can directly run decryptCipher.py as We've already provided plain_texts.txt and cipher_texts.txt in this directory.


