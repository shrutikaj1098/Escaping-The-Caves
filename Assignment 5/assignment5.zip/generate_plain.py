l = ['f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u']
sl = []
for x in range(8):
    ps = []
    for i in range(8):
        for j in range(16):
            st = 'ff{}{}{}ff{}'.format(x, l[i], l[j], (8-1-x))
            ps.append(st)
    sl.append(ps)

with open('plain_texts.txt', 'w') as file:
    for i in sl:
        st = ' '.join(i) + '\n'
        file.write(st)
    file.close()
