
- gen_plaintext.py is for generating plaintexts1.txt and plaintexts2.txt, run it once and both will be created.
- run_script.py is for generating ciphertexts1.txt and ciphertexts2.txt. Run this file twice by changing the output filenames as ciphertexts1.txt and ciphettexts.txt second time.
- diffCryptoAnalysis.pynb is for finding out the decoded keys and 56bit overall differential cryptoanalysios. Input files given here are ciphertexts1.txt and ciphertexts2.txt.
- fin_des.cpp is for generating the final output, which gives us the correct output password with padding.
- Other files are plaintexts1.txt,plaintexts2.txt,ciphertexts1.txt,ciphertexts2.txt which are already generated using aboce files and can be directly used for analysis.
